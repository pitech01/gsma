const MeetingRoom = () => {
    return (
        <div>MeetingRoom</div>
    );
}

export default MeetingRoom;